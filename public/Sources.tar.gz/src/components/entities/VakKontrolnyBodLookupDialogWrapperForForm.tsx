import React from 'react'
import { LookupDialog } from './LookupDialog'
import VakKontrolnyBodDataTableContainerForForm from './vak_kontrolny_bod/VakKontrolnyBodDataTableContainerForForm'
import VakKontrolnyBodDataTableGridViewForForm from './vak_kontrolny_bod/VakKontrolnyBodDataTableGridViewListForForm'
import Button from '@mui/material/Button'
import { Search } from '@mui/icons-material'
import { Translate } from '@iteria-app/component-templates'
type Props = {
  setFieldValue: (field: string, value: any, shouldValidate?: boolean) => void
  replacedValue: string
}
export const VakKontrolnyBodLookupDialogWrapperForForm = ({
  setFieldValue,
  replacedValue,
}: Props) => {
  return (
    <LookupDialog
      Container={VakKontrolnyBodDataTableContainerForForm}
      View={VakKontrolnyBodDataTableGridViewForForm}
      onClickRow={(row) => {
        setFieldValue(replacedValue, row, false)
      }}
      title={replacedValue}
    >
      <Button
        color="secondary"
        variant="contained"
        startIcon={<Search />}
        style={{ margin: '16px' }}
      >
        <Translate
          entityName={replacedValue}
          fieldName="lookup"
          defaultMessage={`Lookup ${replacedValue}`}
        />
      </Button>
    </LookupDialog>
  )
}
