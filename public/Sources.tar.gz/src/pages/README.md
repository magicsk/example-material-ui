Pages with automated file based routing here in subfolders.
