import { defaultTheme } from './default'
import { mTheme } from './mtheme'

const availbleThemes = [defaultTheme, mTheme]

export const theme = availbleThemes[1]
