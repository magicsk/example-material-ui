import React from 'react'

export const DefaultFormat = () => {
  return <div style={{ height: '100px', width: '100%', clear: 'both' }}></div>
}
