const routes = []
export default routes
export const filebasedRouting: Record<
  string,
  {
    [key: string]: any
  }
>
